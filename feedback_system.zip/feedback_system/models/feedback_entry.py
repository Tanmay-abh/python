
# models/feedback_entry.py

class FeedbackEntry:
    def __init__(self, student_id, course_id, rating, comments):
        self.student_id = student_id
        self.course_id = course_id
        self.rating = rating
        self.comments = comments
